License Test Client				
by: IamMayen
TO RUN Client App exe											
	/bin/Debug/validate.exe										
	In Terminal										
											
	validate -u 192.168.0.18 -p 3000 -l ffYJGiFGfPg0 -n Test -s M2X27PA#AJ										
											
		  -u        Required. Server IP address.									
											
		  -p        Required. Server Port.									
											
		  -m INT    (Default: 1) 1 - App1 | 2 - App2 Application.									
											
		  -l        Required. Application license.									
											
		  -s        Required. System SKU.									
											
		  -n        Required. Username Registered for the License.									
											
		  --help    Display this help screen.									
