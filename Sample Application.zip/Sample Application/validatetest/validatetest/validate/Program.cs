﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using System.Security.Cryptography;
using System.Web.Script.Serialization;

namespace validate
{
    class Program
    {
        static string gstrIV;

        public static int Main(string[] args)
        {
            var options = new Options();
            Console.WriteLine(args);
            if ( !(CommandLine.Parser.Default.ParseArguments(args, options)) )
            {
                // manage the failure here
                Console.ReadKey();
                return -2;
            }

            Console.ReadKey();
            string url = options.ServerUrl;
            string portno = options.ServerPort;
            string serverpath = "http://" + url + ":" + portno;
            
            // Request TOKEN 
            string token_api = serverpath + "/licserver/token";
            Console.WriteLine(token_api);
            try
            {
                // Create a request using a URL that can receive a post. 
                WebRequest request = WebRequest.Create(token_api);
                request.Method = "POST";
                request.ContentType = "application/x-www-form-urlencoded";
                // Get the response.
                WebResponse response = request.GetResponse();
                // Display the status.
                Console.WriteLine(((HttpWebResponse)response).StatusDescription);
                // Get the stream containing content returned by the server.
                Stream dataStream = response.GetResponseStream();
                // Open the stream using a StreamReader for easy access.
                StreamReader reader = new StreamReader(dataStream);
                // Read the content.
                string responseFromServer = reader.ReadToEnd();
                // Display the content.
                Console.WriteLine(responseFromServer);
                // Clean up the streams.
                reader.Close();
                dataStream.Close();
                response.Close();

                var jss = new JavaScriptSerializer();
                dynamic obj = jss.Deserialize(responseFromServer, typeof(object));
                Console.WriteLine(obj["key"]);
                string strKey = obj["key"];

                string sLicense = "lic=" + options.LicenseString;
                sLicense = sLicense + "&sku=" + options.SystemSKU;
                sLicense = sLicense + "&name=" + options.Username;
                Console.WriteLine("sLicense: {0}", sLicense);

                string encrypt = Encrypt(sLicense, strKey, false);
                Console.WriteLine("encrypted as: {0}", encrypt);

                // create a new instance of WebClient
                WebClient client = new WebClient();

                string sMessage = "key=" + strKey;
                sMessage = sMessage + "&IV=" + gstrIV;
                sMessage = sMessage + "&encode=" + encrypt;
                Console.WriteLine("sMessage: {0}", sMessage);
                string auth_api;
                Console.WriteLine("AppNo: {0}", options.AppNo);
                if (options.AppNo == 1)
                {
                    auth_api = serverpath + "/licserver/app1/auth";
                }
                else if (options.AppNo == 2)
                {
                    auth_api = serverpath + "/licserver/app2/auth";
                }
                else
                {
                    Console.WriteLine("1 - App1 | 2 - App2 ", "Invalid Application");
                    //Console.ReadKey();
                    return 0;
                }

                try
                {

                    byte[] bret = client.UploadData(auth_api, "POST",
                    System.Text.Encoding.ASCII.GetBytes(sMessage));

                    string sret = System.Text.Encoding.ASCII.GetString(bret);
                    Console.WriteLine("sret: {0}", sret);

                    obj = jss.Deserialize(sret, typeof(object));
                    if ((obj["status"]) == "success")
                    {
                        Console.WriteLine(obj["status"]);
                        Console.ReadKey();
                        return 0;
                    }
                    else
                    {
                        int exitCode = 0;

                        exitCode = obj["error"];
                        Console.WriteLine(exitCode);
                        Console.WriteLine(obj["message"]);

                        Console.ReadKey();
                        return exitCode;
                    }

                }
                catch (WebException we)
                {
                    // WebException.Status holds useful information
                    Console.WriteLine(we.Message + "\n" + we.Status.ToString());
                    Console.ReadKey();
                    return -1;
                }
                catch (NotSupportedException ne)
                {
                    // other errors
                    Console.WriteLine(ne.Message);
                    Console.ReadKey();
                    return -1;
                }

            }
            catch (WebException ex)
            {
                if (ex.Response != null)
                {
                    using (WebResponse response = ex.Response)
                    {
                        HttpWebResponse httpResponse = (HttpWebResponse)response;

                        Console.WriteLine("HTTP " + httpResponse.ProtocolVersion + "\t " + ((int)httpResponse.StatusCode) + "\t" +
                            httpResponse.StatusDescription);

                        using (Stream temp = response.GetResponseStream())
                        {
                            string text = new StreamReader(temp).ReadToEnd();
                            Console.WriteLine(text);
                        }
                    }
                }

                Console.WriteLine("Connection Error", "Error");
                //Console.ReadKey();
                return -1;
            }
            //Console.ReadKey();
            return 0;
        }

        static string Encrypt(string toEncrypt, string key, bool useHashing)
        {
            byte[] keyArray;
            byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(toEncrypt);

            if (useHashing)
            {
                MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
            }
            else
            {
                keyArray = UTF8Encoding.UTF8.GetBytes(key);
            }

            var tdes = new TripleDESCryptoServiceProvider();
            tdes.Key = keyArray;
            // tdes.Mode = CipherMode.CBC;  // which is default     
            // tdes.Padding = PaddingMode.PKCS7;  // which is default

            Console.WriteLine("iv: {0}", Convert.ToBase64String(tdes.IV));
            gstrIV = Convert.ToBase64String(tdes.IV);

            ICryptoTransform cTransform = tdes.CreateEncryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0,
                toEncryptArray.Length);
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }

    }
}
