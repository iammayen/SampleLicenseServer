﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommandLine;
using CommandLine.Text; // if you want text formatting helpers (recommended)

namespace validate
{
    class Options
    {
        [Option('u', Required = true,
         HelpText = "Server IP address.")]
        public string ServerUrl { get; set; }

        [Option('p', Required = true,
         HelpText = "Server Port.")]
        public string ServerPort { get; set; }

        [Option('m', MetaValue = "INT", DefaultValue = 1, HelpText = "1 - App1 | 2 - App2 Application.")]
        public int AppNo { get; set; }

        [Option('l', Required = true,
         HelpText = "Application license.")]
        public string LicenseString { get; set; }

        [Option('s', Required = true,
        HelpText = "System SKU.")]
        public string SystemSKU { get; set; }

        [Option('n', Required = true,
        HelpText = "Username Registered for the License.")]
        public string Username { get; set; }

        [ParserState]
        public IParserState LastParserState { get; set; }

        [HelpOption]
        public string GetUsage()
        {
            return HelpText.AutoBuild(this,
              (HelpText current) => HelpText.DefaultParsingErrorsHandler(this, current));
        }
    }
}
