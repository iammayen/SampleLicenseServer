Validation Server Setup and Sample Test client			
by: IamMayen

Server: Node.js
Client App: C#							

		 
		 
