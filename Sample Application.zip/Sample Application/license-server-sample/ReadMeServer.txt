License Server				
by: IamMayen

Server: CentOS
Server Engine: Node.js
Database: MongoDB NoSQL Database Engine

Dependencies:
"express" : "~4.0.0
"ejs" : "~0.8.5",
"mongoose" : "~3.8.
"passport" : "~0.1.
"passport-local" : 
"connect-flash" : "
"bcrypt-nodejs" : "

"morgan": "~1.0.0",
"body-parser": "~1.
"cookie-parser": "~
"method-override": 
"express-session": 
"console-stamp": "0
"express-logger": "
"fs-extra": "0.23.1
"path": "0.11.14"


#cd /license-server
#node server.js

[1] URL
http://xxx.xxx.xxx.xxx:3000/licserver	

[2] Click Login	
username: your@email.com			
password: yourpassword
*please refer to code		
	
[3] Main MENU	
	
3.1] Add new License	
3.2] Display All License	
3.3] Delete License	
3.4] Admin User Signup	
3.5] Logout	
	
========================================================================================================
APIs

?POST http://xxx.xxx.xxx.xxx:3000/licserver/token														
	Server Response														
		{													
		"key:"512a98d9954c77ae"			-> this KEYVALUE is used for encryption										
		}													
Encryption should be flexible, depends on the usages.
		
For Application1 Product														
? http://xxx.xxx.xxx.xxx:3000/licserver/App1/auth														
		HTTP Request Data:													
			key=[KEYVALUE]&IV=[IVVALUE]&encode=[ENCRYPTED lic-sku-name]												
															
			ENCRYPTED lic-sku-name												
			lic=ENCRYPTED&sku=ENCRYPTED&name=ENCRYPTED												
			where:												
			 lic = license value (must be a registered value)												
			 sku= system sku												
			 name = username (must be a registered value)
												
For Application2 Product													
?  http://xxx.xxx.xxx.xxx:3000/licserver/App2/auth														
		HTTP Request Data:													
			key=[KEYVALUE]&IV=[IVVALUE]&encode=[ENCRYPTED lic-sku-name]												
															
			ENCRYPTED lic-sku-name												
			lic=ENCRYPTED&sku=ENCRYPTED&name=ENCRYPTED												
			where:												
			 lic = license value (must be a registered value)												
			 sku= system sku												
			 name = username (must be a registered value)												

========================================================================================================								
HTTP Responses:														
	* responses are in JSON format:														
	OK														
	status: success														
	ERRORS														
	status: error														
	error:														
	1: Illegal License														
	2: Multiple install														
	3: Empty License Param														
	4: Empty SKU Param														
	5: Internal Error	-> these error are used internally in the server app (5,6)										
	6: License Duplication														
	7: Empty Username Param														
	8: Empty Key Param														
	9: Empty Iv Param														
	10: Empty Encode Param														
	11: Error Decryption														
	12: Empty Http Data														
	13: Invalid  Http Data Sent														

========================================================================================================								
For Data Encrytion Usage (Recommendation):
System.Security.Cryptography.TripleDESCryptoServiceProvider class in C#														
	*can be used for encyption														
															
Crypto module of Node.JS														
	*can be used for the decryption														
		 algorithm = 'des-ede-cbc',													

		 
		 
