// server.js

// set up ======================================================================
// get all the tools we need
var express  = require('express');
var app      = express();
var port     = process.env.PORT || 3000;
var mongoose = require('mongoose');
var passport = require('passport');
var flash    = require('connect-flash');

var morgan       = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser   = require('body-parser');
var session      = require('express-session');

var https 		= require('https');      // module for https
var fs      	= require('fs-extra');
var logger      = require('express-logger');
var http        = require('http');

var configDB = require('./config/database.js');
var User     = require('./app/models/user');

//SERVER LOGS
//===============================================================
require("console-stamp")(console, "yyy-mm-dd HH:MM:ss.l");
app.use(logger({path: __dirname + "/server.log"}));

//SSL ENABLE
//===============================================================
//var sslOptions = {
  //key: fs.readFileSync( __dirname + '/config/ssl/server.key'),
  //cert: fs.readFileSync( __dirname + '/config/ssl/server.crt'),
  //ca: fs.readFileSync( __dirname + '/config/ssl/ca.crt'),
  //requestCert: true,
  //rejectUnauthorized: false
//};

// configuration ===============================================================
mongoose.connect(configDB.url); // connect to our database

//Create Default Admin
User.findOne({ 'local.email' : "map.salarda@gmail.com" }, function(err, user) {
   // if there are any errors, return the error
   if (err)
   {
   		console.log("ERROR: Some error accessing the DB: " + err);
   		process.exit(1);
   }
   else
   {
   	  //console.log(user);    
      if ( user == null )
      {
      		// create default user
            var newUser = new User();

            newUser.local.email    = "map.salarda@gmail.com";
            newUser.local.password = newUser.generateHash("IamMayen");
            
            newUser.save(function(err) {
	            if (err)
	            {
	              console.log("ERROR: Creating a default Admin user: " + err);
	              process.exit(1);
	            }
	            console.log("Save Default User");        
            });
      }
      else
      {
      	console.log("Default User Exist: " + user.local.email);
      }
   }

});    

require('./config/passport')(passport); // pass passport for configuration

// set up our express application
app.use(morgan('dev')); // log every request to the console
app.use(cookieParser()); // read cookies (needed for auth)
app.use(bodyParser.json()); // get information from html forms
app.use(bodyParser.urlencoded({ extended: true }));

app.set('view engine', 'ejs'); // set up ejs for templating

// required for passport
app.use(session({ secret: 'licenseserver' }));
app.use(passport.initialize());
app.use(passport.session()); // persistent login sessions
app.use(flash()); // use connect-flash for flash messages stored in session

app.use( express.static( "public" ) );

// routes ======================================================================
require('./app/routes.js')(app, passport); // load our routes and pass in our app and fully configured passport

// launch ======================================================================
app.listen(port);
console.log('The magic happens on port ' + port);

//SSL ENABLE
//var secureServer = https.createServer(sslOptions, app).listen(port, function(){
//	console.log('Secure License server listening on port ' + port);
//});